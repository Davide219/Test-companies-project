package it.generationitaly.appauto.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import it.generationitaly.appauto.entity.Automobile;
import it.generationitaly.appauto.entity.Utente;
import it.generationitaly.appauto.repository.UtenteRepository;

public class UtenteRepositoryImpl extends CrudRepositoryImpl<Utente, Integer> implements UtenteRepository{

	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("persistence");
	public UtenteRepositoryImpl() {
		super(Utente.class);
		
	}

	
	@Override
	public Utente findByUsername(String username) {
		Utente utente = null;
		EntityManager em =null;
		EntityTransaction tx =null;
		try {
			 em = emf.createEntityManager();
				 tx = em.getTransaction();
				 tx.begin();
				 TypedQuery<Utente>q = em.createQuery("From Utente u where u.username = :c",Utente.class);
				 q.setParameter("c", username);
				 utente = q.getSingleResult();
				 tx.begin();
		} catch (Exception e) {
			if(tx != null && tx.isActive()) {
				tx.rollback();
			}
		}finally {
			if( em != null) {
				em.close();
			}
		}
		return utente;
	}


	@Override
	public Utente findByEmail(String Email) {
		Utente utente = null;
		EntityManager em =null;
		EntityTransaction tx =null;
		try {
			 em = emf.createEntityManager();
				 tx = em.getTransaction();
				 tx.begin();
				 TypedQuery<Utente>q = em.createQuery("from Utente u where u.mail =:mail",Utente.class);
				 q.setParameter("mail", Email);
				 utente = q.getSingleResult();
				 tx.begin();
		} catch (Exception e) {
			if(tx != null && tx.isActive()) {
				tx.rollback();
			}
		}finally {
			if( em != null) {
				em.close();
			}
		}
		return utente;
	}
	}


	
		
	
	
	


