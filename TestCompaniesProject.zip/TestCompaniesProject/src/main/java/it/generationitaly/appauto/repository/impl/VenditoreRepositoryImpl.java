package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Venditore;
import it.generationitaly.appauto.repository.VenditoreRepository;

public class VenditoreRepositoryImpl extends CrudRepositoryImpl<Venditore, Integer> implements VenditoreRepository {

	public VenditoreRepositoryImpl() {
		super(Venditore.class);

	}

}