package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.sql.Date;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Automobile;
import it.generationitaly.appauto.entity.Cambio;
import it.generationitaly.appauto.entity.Carburante;
import it.generationitaly.appauto.entity.Colore;
import it.generationitaly.appauto.entity.Foto;
import it.generationitaly.appauto.entity.Porte;
import it.generationitaly.appauto.entity.Utente;
import it.generationitaly.appauto.entity.Venditore;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.AutomobileRepository;
import it.generationitaly.appauto.repository.CambioRepository;
import it.generationitaly.appauto.repository.CarburanteRepository;
import it.generationitaly.appauto.repository.ColoreRepository;
import it.generationitaly.appauto.repository.FotoRepository;
import it.generationitaly.appauto.repository.PorteRepository;
import it.generationitaly.appauto.repository.UtenteRepository;
import it.generationitaly.appauto.repository.VenditoreRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.AutomobileRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CambioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CarburanteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.ColoreRepositoryImpl;
import it.generationitaly.appauto.repository.impl.FotoRepositoryImpl;
import it.generationitaly.appauto.repository.impl.PorteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.UtenteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.VenditoreRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SaveAnnuncio")
public class SaveAnnuncioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private FotoRepository fotoRepository = new FotoRepositoryImpl();
	private VenditoreRepository venditoreRepository= new VenditoreRepositoryImpl(); 
	private AnnuncioRepository annuncioRepository = new AnnuncioRepositoryImpl();
	private PorteRepository porterepository= new PorteRepositoryImpl();
	private AutomobileRepository automobileRepository = new AutomobileRepositoryImpl();
	private CambioRepository cambioRepository= new CambioRepositoryImpl();
	private UtenteRepository utenteRepository = new UtenteRepositoryImpl();
	private CarburanteRepository carburanteRepository= new CarburanteRepositoryImpl();
	private ColoreRepository coloreRepository= new ColoreRepositoryImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Integer utenteId =(Integer) request.getSession().getAttribute("utente");
		String marca = request.getParameter("marca");
		String modello = request.getParameter("modello");
		Integer CambioId =Integer.parseInt( request.getParameter("cambio"));
		Integer CarburanteId =Integer.parseInt( request.getParameter("carburante"));
		Integer ColoreId =Integer.parseInt( request.getParameter("colore"));
		String foto1 = request.getParameter("foto1");
		String foto2 = request.getParameter("foto2");
		String foto3 = request.getParameter("foto3");
		int prezzo = Integer.parseInt(request.getParameter("prezzo"));
		int km = Integer.parseInt(request.getParameter("km"));
		int cilindrata = Integer.parseInt(request.getParameter("cilindrata"));
		Integer anno = Integer.parseInt(request.getParameter("anno"));
		Integer venditoreId =Integer.parseInt( request.getParameter("venditore"));
		int porte = Integer.parseInt(request.getParameter("porte"));

		Automobile automobile = new Automobile();
		automobile.setMarca(marca);
		automobile.setModello(modello);
		automobile.setAnno(anno);
		automobile.setPrezzo(prezzo);
		automobile.setCilindrata(cilindrata);
		automobile.setKm(km);

		Utente utente = utenteRepository.findById(utenteId);
		automobile.setUtente(utente);

		Venditore venditore =venditoreRepository.findById(venditoreId);
		automobile.setVenditore(venditore);

		Porte porteObject = porterepository.findById(porte);
		automobile.setPorte(porteObject);

		Cambio cambio = cambioRepository.findById(CambioId);
		automobile.setCambio(cambio);

		Carburante carburante =carburanteRepository.findById(CarburanteId);
		automobile.setCarburante(carburante);

		Colore colore = coloreRepository.findById(ColoreId);
		automobile.setColore(colore);

		Integer autoId=automobileRepository.saveReturnId(automobile);
		Automobile autosalvata=automobileRepository.findById(autoId);
		Annuncio annuncio = new Annuncio();
		if(autosalvata!= null) {
		
		String titolo = request.getParameter("titolo");
		String dataString = request.getParameter("dataAnnuncio");
		Date data = Date.valueOf(dataString);
		String citta = request.getParameter("citta");
		String provincia = request.getParameter("provincia");
		String cap = request.getParameter("cap");
		annuncio.setTitolo(titolo);
		annuncio.setDataAnnuncio(data);
		annuncio.setCitta(citta);
		annuncio.setProvincia(provincia);
		annuncio.setCap(cap);
		annuncio.setUtente(utente);
		annuncio.setAutomobile(autosalvata);
		}
		Integer idAnnuncio=annuncioRepository.saveReturnId(annuncio);
		Annuncio annuncioSalvato=annuncioRepository.findById(idAnnuncio);
		if(annuncioSalvato!=null) {
			System.out.println("sono entrato");
		Foto fotoObject1 = new Foto();
		fotoObject1.setNome(foto1);
		fotoObject1.setAnnuncio(annuncioSalvato);
		fotoRepository.save(fotoObject1);

		Foto fotoObject2 = new Foto();
		fotoObject2.setNome(foto2);
		fotoObject2.setAnnuncio(annuncioSalvato);
		fotoRepository.save(fotoObject2);

		Foto fotoObject3 = new Foto();
		fotoObject3.setNome(foto3);
		fotoObject3.setAnnuncio(annuncioSalvato);
		fotoRepository.save(fotoObject3);
		}
		response.sendRedirect("annunci");

	}

}
