package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Cambio;
import it.generationitaly.appauto.repository.CambioRepository;

public class CambioRepositoryImpl extends CrudRepositoryImpl<Cambio, Integer> implements CambioRepository {

	public CambioRepositoryImpl() {
		super(Cambio.class);

	}

}