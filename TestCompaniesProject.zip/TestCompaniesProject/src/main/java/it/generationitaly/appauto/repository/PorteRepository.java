package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Porte;

public interface PorteRepository extends CrudRepository<Porte, Integer> {

}
