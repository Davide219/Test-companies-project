package it.generationitaly.appauto.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "annuncio")
public class Annuncio {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "titolo", length = 50, nullable = false)
	private String titolo;

	@Column(name = "citta", length = 50, nullable = false)
	private String citta;

	@Column(name = "provincia", length = 50, nullable = false)
	private String provincia;

	@Column(name = "cap", length = 50, nullable = false)
	private String cap;

	@Column(name = "data_annuncio", length = 50, nullable = false)
	private Date dataAnnuncio;

	@ManyToOne
	@JoinColumn(name = "id_utente", nullable = false)
	private Utente utente;

	@OneToOne
	@JoinColumn(name = "id_automobile", nullable = false)
	private Automobile automobile;

	@OneToMany(mappedBy = "annuncio", fetch = FetchType.EAGER)
	private List<Foto> foto;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getCitta() {
		return citta;
	}

	public void setCitta(String citta) {
		this.citta = citta;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getCap() {
		return cap;
	}

	public void setCap(String cap) {
		this.cap = cap;
	}

	public Date getDataAnnuncio() {
		return dataAnnuncio;
	}

	public void setDataAnnuncio(Date dataAnnuncio) {
		this.dataAnnuncio = dataAnnuncio;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	public Automobile getAutomobile() {
		return automobile;
	}

	public void setAutomobile(Automobile automobile) {
		this.automobile = automobile;
	}

	public List<Foto> getFoto() {
		return foto;
	}

	public void setFoto(List<Foto> foto) {
		this.foto = foto;
		
	}

	@Override
	public String toString() {
		return "Annuncio [id=" + id + ", titolo=" + titolo + ", citta=" + citta + ", provincia=" + provincia + ", cap="
				+ cap + ", dataAnnuncio=" + dataAnnuncio + "]";
	}



}