package it.generationitaly.appauto.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "automobile")
public class Automobile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "marca", length = 50, nullable = false)
	private String marca;

	@Column(name = "modello", length = 50, nullable = false)
	private String modello;

	@Column(name = "anno", nullable = false)
	private Integer anno;

	@Column(name = "prezzo", nullable = false)
	private int prezzo;

	@Column(name = "km", nullable = false)
	private int km;

	@ManyToOne
	@JoinColumn(name = "carburante_id", nullable = false)
	private Carburante carburante;

	@ManyToOne
	@JoinColumn(name = " n_porte_id", nullable = false)
	private Porte porte;

	@ManyToOne
	@JoinColumn(name = "colore_id", nullable = false)
	private Colore colore;

	@Column(name = "cilindrata", nullable = false)
	private int cilindrata;

	@ManyToOne
	@JoinColumn(name = "cambio_id", nullable = false)
	private Cambio cambio;

	@ManyToOne
	@JoinColumn(name = "venditore_id", nullable = false)
	private Venditore venditore;

	@ManyToOne
	@JoinColumn(name = "id_utente", nullable = false)
	private Utente utente;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public Integer getAnno() {
		return anno;
	}

	public void setAnno(Integer anno) {
		this.anno = anno;
	}

	public int getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(int prezzo) {
		this.prezzo = prezzo;
	}

	public int getKm() {
		return km;
	}

	public void setKm(int km) {
		this.km = km;
	}

	public Carburante getCarburante() {
		return carburante;
	}

	public void setCarburante(Carburante carburante) {
		this.carburante = carburante;
	}

	public Porte getPorte() {
		return porte;
	}

	public void setPorte(Porte porte) {
		this.porte = porte;
	}

	public Colore getColore() {
		return colore;
	}

	public void setColore(Colore colore) {
		this.colore = colore;
	}

	public int getCilindrata() {
		return cilindrata;
	}

	public void setCilindrata(int cilindrata) {
		this.cilindrata = cilindrata;
	}

	public Cambio getCambio() {
		return cambio;
	}

	public void setCambio(Cambio cambio) {
		this.cambio = cambio;
	}

	public Venditore getVenditore() {
		return venditore;
	}

	public void setVenditore(Venditore venditore) {
		this.venditore = venditore;
	}

	public Utente getUtente() {
		return utente;
	}

	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	@Override
	public String toString() {
		return "Automobile [id=" + id + ", marca=" + marca + ", modello=" + modello + ", anno=" + anno + ", prezzo="
				+ prezzo + ", km=" + km + ", carburante=" + carburante + ", porte=" + porte + ", colore=" + colore
				+ ", cilindrata=" + cilindrata + ", cambio=" + cambio + ", venditore=" + venditore + ", utente="
				+ utente + "]";
	}
}
