package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Porte;
import it.generationitaly.appauto.repository.PorteRepository;

public class PorteRepositoryImpl extends CrudRepositoryImpl<Porte, Integer> implements PorteRepository {

	public PorteRepositoryImpl() {
		super(Porte.class);

	}

}