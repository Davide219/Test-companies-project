package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Carburante;
import it.generationitaly.appauto.repository.CarburanteRepository;

public class CarburanteRepositoryImpl extends CrudRepositoryImpl<Carburante, Integer> implements CarburanteRepository {

	public CarburanteRepositoryImpl() {
		super(Carburante.class);

	}

}