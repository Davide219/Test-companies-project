  package it.generationitaly.appauto.controller;

import java.io.IOException;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/dettaglioAuto")
public class DettaglioAutoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String idAsString = request.getParameter("id");
		 int id= Integer.parseInt(idAsString);
		 AnnuncioRepository annRep =new AnnuncioRepositoryImpl();
		 Annuncio annuncio = annRep.findById(id);
		 request.setAttribute("annuncio", annuncio);
		 request.getRequestDispatcher("info-auto.jsp").forward(request, response);
	}

	
}
