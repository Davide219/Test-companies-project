package it.generationitaly.appauto.repository;


import java.util.List;

import it.generationitaly.appauto.entity.Automobile;

public interface AutomobileRepository extends CrudRepository<Automobile, Integer> {
	List<String> findAllDistinctMarche();
	List<String> findAllDistinctModelli();
	List<String> findAllDistinctCarburanti();
	
	int saveReturnId(Automobile automobile);
}
