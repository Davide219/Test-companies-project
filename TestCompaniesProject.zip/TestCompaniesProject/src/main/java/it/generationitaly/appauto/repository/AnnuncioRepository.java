package it.generationitaly.appauto.repository;

import java.sql.Date;
import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;


public interface AnnuncioRepository extends CrudRepository<Annuncio, Integer> {
	List<Annuncio> findByMarca(String marca);

	List<Annuncio> findByModello(String modello);

	List<Annuncio> betweenPrezzo(double min, double max);

	List<Annuncio> prezzoAsc();

	List<Annuncio> prezzoDesc();

	List<Annuncio> betweenKm(int min, int max);

	List<Annuncio> kmAsc();

	List<Annuncio> kmDesc();

	List<Annuncio> betweenAnno(Date min, Date max);

	List<Annuncio> annoAsc();

	List<Annuncio> annoDesc();

	List<Annuncio> prezzoAscAndMarca(String marca);

	List<Annuncio> prezzoDescAndMarca(String marca);

	List<Annuncio> kmAscAndMarca(String marca);

	List<Annuncio> kmDescAndMarca(String marca);

	List<Annuncio> annoAscAndMarca(String marca);

	List<Annuncio> annoDescAndMarca(String marca);

	List<Annuncio> findAllLimit6();

	List<Annuncio> orderBy(String marca,Integer porta,String venditore,String cambio,String carburante, Integer prezzoDa, Integer prezzoA, Integer kmDa, Integer kmA, Integer annoDa,
			Integer annoA,String[] colori, String orderBy, String ordine);
	int saveReturnId(Annuncio annuncio);
}
