package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Cambio;

public interface CambioRepository extends CrudRepository<Cambio, Integer> {

}
