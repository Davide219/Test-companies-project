package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Preferiti;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.PreferitiRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.PreferitiRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/preferiti")
public class PreferitiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PreferitiRepository preferitiRepository = new PreferitiRepositoryImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("username");

		if (user == null) {
			response.sendRedirect("login.jsp");

		} else {
			

			List<Preferiti> preferiti = preferitiRepository.findByUsername(user);

			request.setAttribute("annunciPreferiti", preferiti);

			request.getRequestDispatcher("preferiti.jsp").forward(request, response);

		}
	}
}
