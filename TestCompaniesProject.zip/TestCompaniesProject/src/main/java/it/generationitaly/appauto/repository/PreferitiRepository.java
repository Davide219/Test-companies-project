package it.generationitaly.appauto.repository;

import java.util.List;

import it.generationitaly.appauto.entity.Preferiti;

public interface PreferitiRepository extends CrudRepository<Preferiti, Integer> {
	List<Preferiti> findByUsername(String username);
	

}
