package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Automobile;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/marca-servlet")
public class FindbyMarcaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String marca = request.getParameter("marca");
		AnnuncioRepository annuncioRep = new AnnuncioRepositoryImpl();
		List<Annuncio> annunciByMarca = annuncioRep.findByMarca(marca);
		// Automobile automobile = null;
		// for (Annuncio annuncio : annunciByMarca) {
		// automobile = annuncio.getAutomobile();
		// }

		// String marca1=annuncioRep.findAllDistinctMarca(marca);
		// request.setAttribute("marca1", marca1);
		request.setAttribute("marca", marca);
		request.setAttribute("annunci", annunciByMarca);

		request.getRequestDispatcher("annunci.jsp").forward(request, response);
	}

}
