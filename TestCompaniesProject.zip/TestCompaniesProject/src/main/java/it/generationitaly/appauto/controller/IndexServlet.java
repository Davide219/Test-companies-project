package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.AutomobileRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.AutomobileRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AnnuncioRepository annuncioRepository = new AnnuncioRepositoryImpl();
	
	private AutomobileRepository automobileRepository = new AutomobileRepositoryImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Annuncio> annunci = annuncioRepository.findAllLimit6();
		List<String> marche = automobileRepository.findAllDistinctMarche();
		request.setAttribute("annunci", annunci);
		request.setAttribute("marche", marche);
		request.getRequestDispatcher("index.jsp").forward(request, response);

	}

}
