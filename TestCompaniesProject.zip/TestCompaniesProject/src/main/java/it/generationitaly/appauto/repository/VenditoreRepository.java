package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Venditore;

public interface VenditoreRepository extends CrudRepository<Venditore, Integer> {

}
