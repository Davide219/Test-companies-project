package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Utente;

public interface UtenteRepository  extends CrudRepository<Utente, Integer>{
	Utente findByUsername(String username);
	Utente findByEmail(String Email);


}
