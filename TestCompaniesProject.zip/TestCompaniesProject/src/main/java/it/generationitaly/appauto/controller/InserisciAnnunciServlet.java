package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Cambio;
import it.generationitaly.appauto.entity.Carburante;
import it.generationitaly.appauto.entity.Colore;
import it.generationitaly.appauto.entity.Porte;
import it.generationitaly.appauto.entity.Venditore;
import it.generationitaly.appauto.repository.AutomobileRepository;
import it.generationitaly.appauto.repository.CambioRepository;
import it.generationitaly.appauto.repository.CarburanteRepository;
import it.generationitaly.appauto.repository.ColoreRepository;
import it.generationitaly.appauto.repository.PorteRepository;
import it.generationitaly.appauto.repository.VenditoreRepository;
import it.generationitaly.appauto.repository.impl.AutomobileRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CambioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CarburanteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.ColoreRepositoryImpl;
import it.generationitaly.appauto.repository.impl.PorteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.VenditoreRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/InserisciAnnunciServlet")
public class InserisciAnnunciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AutomobileRepository automobileRepository = new AutomobileRepositoryImpl();
	
	private CarburanteRepository carburanteRepository = new CarburanteRepositoryImpl();
	
	private ColoreRepository coloreRepository=new ColoreRepositoryImpl();
	
	private CambioRepository cambioRepository=new CambioRepositoryImpl();
	
	private VenditoreRepository venditoreRepository=new VenditoreRepositoryImpl();
	
	private PorteRepository porteRepository=new PorteRepositoryImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("username");

		if (user == null) {
			response.sendRedirect("login.jsp");

		}else {
		List<String> marche = automobileRepository.findAllDistinctMarche();
		List<String> modelli = automobileRepository.findAllDistinctModelli();
		List<Carburante> carburanti = carburanteRepository.findAll();
		List<Cambio> cambi = cambioRepository.findAll();
		List<Colore> colori = coloreRepository.findAll();
		List<Venditore> venditori = venditoreRepository.findAll();
		List<Porte> porte = porteRepository.findAll();
		
		
		request.setAttribute("marche", marche);
		request.setAttribute("modelli", modelli);
		request.setAttribute("carburanti", carburanti);
		request.setAttribute("colori", colori);
		request.setAttribute("cambi", cambi);
		request.setAttribute("venditori", venditori);
		request.setAttribute("porte", porte);
		
		request.getRequestDispatcher("inserisciAnnuncio.jsp").forward(request, response);
		
		}
		
	}


}
