package PROVA;


import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Automobile;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.AutomobileRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.AutomobileRepositoryImpl;

public class main {

	public static void main(String[] args) {
		 esegui();
	}

	private static void esegui() {

		AnnuncioRepository ar = new AnnuncioRepositoryImpl();
		List<Annuncio> ann = ar.orderBy("km",null,"DESC");
		for (Annuncio annuncio : ann) {
			System.out.println(annuncio);
		}
		
		}
	private static void esegui2() {
	AnnuncioRepository ar = new AnnuncioRepositoryImpl();
	List<Annuncio> ann = ar.annoDescAndMarca("fiat");
	for (Annuncio annuncio : ann) {
		System.out.println(annuncio);
	}

	}
}

