package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Foto;

public interface FotoRepository extends CrudRepository<Foto, Integer>{

}
