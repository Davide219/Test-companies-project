package it.generationitaly.appauto.repository;

import it.generationitaly.appauto.entity.Colore;

public interface ColoreRepository extends CrudRepository<Colore, Integer> {

}
