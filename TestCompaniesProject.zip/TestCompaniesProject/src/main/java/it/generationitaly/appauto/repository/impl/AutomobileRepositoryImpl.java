package it.generationitaly.appauto.repository.impl;

import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import it.generationitaly.appauto.entity.Automobile;
import it.generationitaly.appauto.repository.AutomobileRepository;


public class AutomobileRepositoryImpl extends CrudRepositoryImpl<Automobile, Integer> implements AutomobileRepository {

	public AutomobileRepositoryImpl() {
		super(Automobile.class);
		
	}

	@Override
	public List<String> findAllDistinctMarche() {
		List<String> marche = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<String> q =  em.createQuery("select distinct a.marca from Automobile a ",String.class  );
			 marche = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			if (tx != null && tx.isActive())
				tx.rollback();
		} finally {
			if (em != null)
				em.close();
		}
		return marche ;
	}

	@Override
	public List<String> findAllDistinctModelli() {
		List<String> modelli = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<String> q =  em.createQuery("select distinct a.modello from Automobile a ",String.class  );
			 modelli = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			if (tx != null && tx.isActive())
				tx.rollback();
		} finally {
			if (em != null)
				em.close();
		}
		return modelli ;
	}

	@Override
	public List<String> findAllDistinctCarburanti() {
		List<String> carburanti = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<String> q =  em.createQuery("select distinct a.carburante from Automobile a ",String.class  );
			 carburanti = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			if (tx != null && tx.isActive())
				tx.rollback();
		} finally {
			if (em != null)
				em.close();
		}
		return carburanti ;
	}

	@Override
	public int saveReturnId(Automobile automobile) {
		Integer id =null;
			EntityManager em = null;
			EntityTransaction tx = null;
			try {
				em = emf.createEntityManager();
				tx = em.getTransaction();
				tx.begin();
				em.persist(automobile);
				tx.commit();
				id=automobile.getId();
			} catch (Exception e) {
				System.err.println(e.getMessage());
				if (tx != null && tx.isActive())
					tx.rollback();
			} finally {
				if (em != null)
					em.close();
			}
		return id;
	}
	

}
