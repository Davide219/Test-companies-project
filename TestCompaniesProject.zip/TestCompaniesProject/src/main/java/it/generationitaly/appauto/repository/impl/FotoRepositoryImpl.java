package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Foto;
import it.generationitaly.appauto.repository.FotoRepository;

public class FotoRepositoryImpl extends CrudRepositoryImpl<Foto, Integer> implements FotoRepository {
	
	public FotoRepositoryImpl() {
		super(Foto.class);

	}
}
