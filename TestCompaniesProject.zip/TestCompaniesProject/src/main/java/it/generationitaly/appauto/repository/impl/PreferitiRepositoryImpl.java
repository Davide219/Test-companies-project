package it.generationitaly.appauto.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Preferiti;
import it.generationitaly.appauto.repository.PreferitiRepository;

public class PreferitiRepositoryImpl extends CrudRepositoryImpl<Preferiti, Integer> implements PreferitiRepository {

	public PreferitiRepositoryImpl() {
		super(Preferiti.class);

	}

	@Override
	public List<Preferiti> findByUsername(String username) {
		
		List<Preferiti> preferiti = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Preferiti> q = em
					.createQuery("Select pf from Preferiti pf join pf.utente ut where ut.username = :m", Preferiti.class)
					.setParameter("m", username);

			preferiti = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			System.out.println("mi blocco qui");
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return preferiti;
	}

	

	

}