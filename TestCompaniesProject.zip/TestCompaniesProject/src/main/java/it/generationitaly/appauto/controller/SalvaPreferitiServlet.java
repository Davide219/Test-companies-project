package it.generationitaly.appauto.controller;

import java.io.IOException;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Preferiti;
import it.generationitaly.appauto.entity.Utente;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.PreferitiRepository;
import it.generationitaly.appauto.repository.UtenteRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.PreferitiRepositoryImpl;
import it.generationitaly.appauto.repository.impl.UtenteRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SalvaPreferiti")
public class SalvaPreferitiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PreferitiRepository preferitiRepository = new PreferitiRepositoryImpl();
	private UtenteRepository utenteRepository = new UtenteRepositoryImpl();
	private AnnuncioRepository annuncioRepository = new AnnuncioRepositoryImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		HttpSession session = request.getSession();

		String username = (String) session.getAttribute("username");

		int annuncioidString =Integer.parseInt(request.getParameter("annuncio"));

		
		if(username == null) {
			response.sendRedirect("login.jsp");
			return;
		}

		
		Utente utente = (Utente) utenteRepository.findByUsername(username);
		Annuncio annuncio = (Annuncio) annuncioRepository.findById(annuncioidString);

		Preferiti preferito = new Preferiti();
		preferito.setAnnuncio(annuncio);
		preferito.setUtente(utente);

		preferitiRepository.save(preferito);
		response.sendRedirect("annunci");

	}
}
