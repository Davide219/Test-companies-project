package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Cambio;
import it.generationitaly.appauto.entity.Carburante;
import it.generationitaly.appauto.entity.Colore;
import it.generationitaly.appauto.entity.Porte;
import it.generationitaly.appauto.entity.Venditore;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.AutomobileRepository;
import it.generationitaly.appauto.repository.CambioRepository;
import it.generationitaly.appauto.repository.CarburanteRepository;
import it.generationitaly.appauto.repository.ColoreRepository;
import it.generationitaly.appauto.repository.PorteRepository;
import it.generationitaly.appauto.repository.VenditoreRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.AutomobileRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CambioRepositoryImpl;
import it.generationitaly.appauto.repository.impl.CarburanteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.ColoreRepositoryImpl;
import it.generationitaly.appauto.repository.impl.PorteRepositoryImpl;
import it.generationitaly.appauto.repository.impl.VenditoreRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/annunci")
public class AnnunciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AnnuncioRepository annuncioRepository = new AnnuncioRepositoryImpl();
	
	private AutomobileRepository automobileRepository = new AutomobileRepositoryImpl();
	
	private CarburanteRepository carburanteRepository=new CarburanteRepositoryImpl();
	
	private ColoreRepository coloreRepository=new ColoreRepositoryImpl();
	
	private CambioRepository cambioRepository=new CambioRepositoryImpl();
	
	private VenditoreRepository venditoreRepository=new VenditoreRepositoryImpl();
	
	private PorteRepository porteRepository=new PorteRepositoryImpl();
	
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Annuncio> annunci = null;
		List<String> marche = null;
		List<Carburante> carburanti=null;
		List<Colore> colori=null;
		List<Cambio> cambi=null;
		List<Venditore> venditori=null;
		List<Porte> porte=null;
		

		String prezzoDaString = request.getParameter("prezzoDA");
		Integer prezzoDa = null;
		
		String prezzoAString = request.getParameter("prezzoA");
		Integer prezzoA = null;
		
		String kmDaString = request.getParameter("kmDA");
		Integer kmDa = null;
		
		String kmAString = request.getParameter("kmA");
		Integer kmA = null;
		
		String annoDaString = request.getParameter("annoDA");
		Integer annoDa = null;
		
		String annoAString = request.getParameter("annoA");
		Integer annoA = null;
		
		String[] coloriScelti = request.getParameterValues("coloriScelti");
		
		
		String portaString = request.getParameter("porta");
		Integer porta = null;
		
		String carburante = request.getParameter("carburante");

		String marca = request.getParameter("marca");

		String orderBy = request.getParameter("orderBy");

		String ordine = request.getParameter("ordine");
		
		String cambio=request.getParameter("cambio");
		
		String venditore = request.getParameter("venditore");
		
		if (marca != null && marca.isEmpty()) {
			marca = null;
		}
		if (carburante == null || carburante.isEmpty()) {
			carburante = null;
		}
		if (orderBy == null) {
			orderBy = "prezzo";
		}
		if (ordine == null) {
			ordine = "asc";
		}
		if(cambio==null || cambio.isEmpty()) {
			cambio=null;
		}
		if (prezzoDaString != null && !prezzoDaString.isEmpty()) {
			prezzoDa = Integer.parseInt(prezzoDaString);
		}
		if (prezzoAString != null && !prezzoAString.isEmpty()) {
			prezzoA = Integer.parseInt(prezzoAString);
		}
		if (kmDaString != null && !kmDaString.isEmpty()) {
			kmDa = Integer.parseInt(kmDaString);
		}
		if (kmAString != null && !kmAString.isEmpty()) {
			kmA = Integer.parseInt(kmAString);
		}
		if (annoDaString != null && !annoDaString.isEmpty()) {
			annoDa =Integer.parseInt(annoDaString);
		}
		if (annoAString != null && !annoAString.isEmpty()) {
			annoA = Integer.parseInt(annoAString);
		}
		if (portaString != null && !portaString.isEmpty()) {
			porta =Integer.parseInt(portaString);
		}
		
	
	
		annunci = annuncioRepository.orderBy(marca,porta,venditore,cambio,carburante, prezzoDa, prezzoA, kmDa, kmA, annoDa, annoA,coloriScelti, orderBy, ordine);
		marche = automobileRepository.findAllDistinctMarche();
		colori= coloreRepository.findAll();
		carburanti=carburanteRepository.findAll();
		venditori = venditoreRepository.findAll();
		porte = porteRepository.findAll();
		cambi = cambioRepository.findAll();
		
		
		if(cambio!=null) {
			request.setAttribute("cambio", cambio);
		}
		if (marca != null) {
			request.setAttribute("marca", marca);
		}
		if (prezzoDa != null) {
			request.setAttribute("prezzoDa", prezzoDa);
		}
		if (prezzoA != null) {
			request.setAttribute("prezzoA", prezzoA);
		}
		if (kmDa != null) {
			request.setAttribute("kmDa", kmDa);
		}
		if (kmA != null) {
			request.setAttribute("kmA", kmA);
		}
		if (annoDa != null) {
			request.setAttribute("annoDa", annoDa);
		}
		if (annoA != null) {
			request.setAttribute("annoA", annoA);
		}
		if(carburante!=null) {
			request.setAttribute("carburante", carburante);
		}
		if(coloriScelti!=null) {  request.setAttribute("coloriScelti",coloriScelti);
		}
		if(porta!=null) {
			request.setAttribute("porta", porta);
		}
		if (venditore != null) {
			request.setAttribute("venditore", venditore);
		}
		request.setAttribute("ordine", ordine);
		request.setAttribute("annunci", annunci);
		request.setAttribute("marche", marche);
		request.setAttribute("carburanti", carburanti);
		request.setAttribute("colori", colori);
		request.setAttribute("venditori", venditori);
		request.setAttribute("porte", porte);
		request.setAttribute("cambi", cambi);
		
		request.getRequestDispatcher("annunci.jsp").forward(request, response);

	}
}
