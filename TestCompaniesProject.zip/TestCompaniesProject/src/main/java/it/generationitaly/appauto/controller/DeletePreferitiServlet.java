package it.generationitaly.appauto.controller;

import java.io.IOException;

import it.generationitaly.appauto.repository.PreferitiRepository;
import it.generationitaly.appauto.repository.impl.PreferitiRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeletePreferitiServlet")
public class DeletePreferitiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private PreferitiRepository preferitiRepository = new PreferitiRepositoryImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			
		String annuncioidString = request.getParameter("id_delete");
		int id = 0;
		if(annuncioidString != null) {
			id = Integer.parseInt(annuncioidString);
		}
		preferitiRepository.deleteById(id);
		response.sendRedirect("preferiti");
	}

}
