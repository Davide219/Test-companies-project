package it.generationitaly.appauto.controller;

import java.io.IOException;

import it.generationitaly.appauto.entity.Utente;
import it.generationitaly.appauto.repository.UtenteRepository;
import it.generationitaly.appauto.repository.impl.UtenteRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/SaveUtenteServlet")
public class SaveUtenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UtenteRepository utenterepository = new UtenteRepositoryImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		boolean hasErrors = false;

		if ("".equals(email)) {
			request.setAttribute("error-email", "Il campo email � obbligatorio");
			hasErrors = true;
		}

		if ("".equals(username)) {
			request.setAttribute("error-urename", "Il campo username � obbligatorio");
			hasErrors = true;
		}
		if ("".equals(password)) {
			request.setAttribute("error-password", "Il campo password � obbligatorio");
			hasErrors = true;
		}
		if ("".equals(nome)) {
			request.setAttribute("error-nome", "Il campo nome � obbligatorio");
			hasErrors = true;
		}	
		if ("".equals(cognome)) {
			request.setAttribute("error-cognome", "Il campo cognome � obbligatorio");
			hasErrors = true;
		}


		if (hasErrors) {
			request.getRequestDispatcher("registrazione.jsp").forward(request, response);
		}
		Utente utente = new Utente();
		utente.setMail(email);
		utente.setUsername(username);
		utente.setPassword(password);
		utente.setNome(nome);
		utente.setCognome(cognome);

		utenterepository.save(utente);

		response.sendRedirect("annunci");
	}

}
