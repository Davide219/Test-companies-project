package it.generationitaly.appauto.controller;

import java.io.IOException;

import it.generationitaly.appauto.entity.Utente;
import it.generationitaly.appauto.repository.UtenteRepository;
import it.generationitaly.appauto.repository.impl.UtenteRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LogInServlet")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static UtenteRepository utenteRepository = new UtenteRepositoryImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email = request.getParameter("Username");
		String password = request.getParameter("password");

		boolean hasErrors = false;

		if ("".equals(email)) {
			// request.setAttribute("error-username", "Il campo username � obbligatorio");
			System.out.println("1");
			hasErrors = true;
		}

		if ("".equals(email)) {
			// request.setAttribute("error-password", "Il campo password � obbligatorio");
			System.out.println("2");
			hasErrors = true;
		}

		if (hasErrors) {
			response.sendRedirect("login.jsp?credenzialierrate");
			// request.getRequestDispatcher("index.jsp").forward(request, response);
//            return;
		}

		Utente utente = utenteRepository.findByEmail(email);

		if (utente != null && utente.getPassword().equals(password)) {
          HttpSession session = request.getSession();
         session.setAttribute("utente", utente.getId());
         session.setAttribute("username", utente.getUsername());

		//response.sendRedirect("annunci");
     response.sendRedirect(request.getContextPath());

		} else {

		
			
			response.sendRedirect("login.jsp");

		}

	}

}
