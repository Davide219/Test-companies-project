package it.generationitaly.appauto.controller;

import java.io.IOException;
import java.util.List;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.repository.AnnuncioRepository;
import it.generationitaly.appauto.repository.impl.AnnuncioRepositoryImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/lista-all-annunci")
public class FindAllAnnunciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		AnnuncioRepository annuncioRep = new AnnuncioRepositoryImpl();
		List<Annuncio> annunci = annuncioRep.findAll();
		request.setAttribute("annunci", annunci);
		request.getRequestDispatcher("annunci.jsp").forward(request, response);
	}

}
