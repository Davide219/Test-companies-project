-- creare tabella Automobile Annuncio Utente Foto.
-- automobile N<-->1 Inserzionista--
-- Inserzionista 1<--> N annuncio--
-- Annuncio 1 <--> N Foto--
-- Annuncio 1 <--> 1 Automobile--

CREATE SCHEMA jaita72_projectwork_autoscout;
USE jaita72_projectwork_autoscout;

CREATE TABLE automobile(
	id INT PRIMARY KEY AUTO_INCREMENT,
    marca VARCHAR(50) NOT NULL ,
    modello VARCHAR(50) NOT NULL,
    anno INT NOT NULL,
    prezzo DOUBLE NOT NULL CHECK (prezzo>0),
    km INT NOT NULL CHECK (km>=0),
    carburante_id INT NOT NULL REFERENCES carburante(id),
    n_porte_id INT NOT NULL REFERENCES n_porte(id),
    colore_id INT NOT NULL REFERENCES colore(id) ,
    cilindrata INT NOT NULL CHECK (cilindrata>50),
    cambio_id INT NOT NULL REFERENCES cambio(id),
    venditore_id INT NOT NULL REFERENCES venditore(id),
	id_utente INT NOT NULL REFERENCES utente(id)
);

CREATE TABLE annuncio(
	id INT PRIMARY KEY AUTO_INCREMENT,
    titolo VARCHAR(50) NOT NULL,
	data_annuncio DATE NOT NULL,
	citta VARCHAR(50) NOT NULL,
	provincia CHAR(2) NOT NULL,
	cap  CHAR(5) NOT NULL,
    id_utente INT NOT NULL REFERENCES utente(id),
    id_automobile INT NOT NULL REFERENCES automobile(id)
);

CREATE TABLE utente(
	id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    mail VARCHAR(50) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL
);

CREATE TABLE foto(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL,
	id_annuncio INT NOT NULL REFERENCES annuncio(id)
);

CREATE TABLE carburante(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL
);
CREATE TABLE colore(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL UNIQUE,
	nome_ing VARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE cambio(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE n_porte(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome INT NOT NULL 
);
CREATE TABLE venditore(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE preferiti(
	id INT PRIMARY KEY AUTO_INCREMENT,
	utente_id INT NOT NULL REFERENCES utente(id),
    annuncio_id INT NOT NULL REFERENCES annuncio(id),
    UNIQUE (utente_id,annuncio_id)
);

DROP TABLE automobile;
DROP TABLE annuncio;
DROP TABLE utente;
DROP TABLE foto;
DROP TABLE colore;
DROP TABLE venditore;
DROP TABLE cambio;
DROP TABLE n_porte;
DROP TABLE carburante;





INSERT INTO venditore VALUES(1,"PRIVATO");
INSERT INTO venditore VALUES(2,"AZIENDA");


INSERT INTO n_porte VALUES(1,3);
INSERT INTO n_porte VALUES(2,5);
INSERT INTO n_porte VALUES(3,7);

INSERT INTO cambio VALUES(1,"AUTOMATICO");
INSERT INTO cambio VALUES(2,"MANUALE");
INSERT INTO cambio VALUES(3,"SEQUENZIALE");

INSERT INTO colore VALUES(1,"VERDE","GREEN");
INSERT INTO colore VALUES(2,"GRIGIO","GRAY");
INSERT INTO colore VALUES(3,"BLU","BLUE");
INSERT INTO colore VALUES(4,"BIANCO","WHITE");
INSERT INTO colore VALUES(5,"NERO","BLACK");
INSERT INTO colore VALUES(6,"ROSSO","RED");
INSERT INTO colore VALUES(7,"GIALLO","YELLOW");
INSERT INTO colore VALUES(8,"VIOLA","PURPLE");
INSERT INTO colore VALUES(9,"MARRONE","BROWN");

INSERT INTO carburante VALUES(1,"BENZINA");
INSERT INTO carburante VALUES(2,"METANO");
INSERT INTO carburante VALUES(3,"GPL");
INSERT INTO carburante VALUES(4,"DIESEL");
INSERT INTO carburante VALUES(5,"ELETTRICO");
INSERT INTO carburante VALUES(6,"IBRIDO");


INSERT INTO automobile VALUES(1,'FIAT','PANDA','1998',5000,300000,2,2,1,1100,2,1,1);
INSERT INTO automobile VALUES(2,'FIAT','PANDA','2008',3500,212000,1,2,2,1200,2,1,2);
INSERT INTO automobile VALUES(3,'FIAT','PANDA','2016',5300,131000,4,2,4,1300,2,1,3);
INSERT INTO automobile VALUES(4,'FIAT','PANDA','2016',10300,90000,3,2,3,1200,2,1,4);
INSERT INTO automobile VALUES(5,'AUDI','A3','2018',16950,186000,4,2,5,1600,1,1,5);
INSERT INTO automobile VALUES(6,'AUDI','A3','2016',18900,109000,4,2,4,2000,2,1,6);
INSERT INTO automobile VALUES(7,'AUDI','RS3','2018',43900,98000,1,2,5,2500,2,2,7);
INSERT INTO automobile VALUES(8,'ALFA ROMEO','STELVIO','2019',28900,119000,4,2,2,2200,1,1,8);
INSERT INTO automobile VALUES(9,'ALFA ROMEO','GIULIA','2018',59500,50000,1,2,5,2900,3,1,9);
INSERT INTO automobile VALUES(10,'ALFA ROMEO','STELVIO','2020',89000,26000,1,2,1,2900,1,1,10);
INSERT INTO automobile VALUES(11,'BMW','320','2012',13000,150000,4,2,2,2000,3,1,11);
INSERT INTO automobile VALUES(12,'BMW','320 M','2022',48000,18000,5,2,2,2000,1,1,12);
INSERT INTO automobile VALUES(13,'BMW','M3','2017',60000,45000,'1',2,4,3000,1,2,13);
INSERT INTO automobile VALUES(14,'MERCEDES-BENZ','A180','2017',14000,190000,'4',2,2,1400,1,1,14);
INSERT INTO automobile VALUES(15,'MERCEDES-BENZ','A45 AMG','2020',59600,23000,'1',2,2,2000,3,1,15);
INSERT INTO automobile VALUES(16,'MERCEDES-BENZ','C63 AMG','2019',81600,55000,'1',2,5,4000,3,1,16);
INSERT INTO automobile VALUES(17,'MASERATI','GRANTURISMO','2016',73800,80000,'1',1,5,4500,1,1,17);
INSERT INTO automobile VALUES(18,'MASERATI','GHIBLI','2021',67000,16000,'1',2,5,2000,1,1,18);
INSERT INTO automobile VALUES(19,'MASERATI','GRANCABRIO','2018',127600,11000,'1',1,4,4600,1,1,19);
INSERT INTO automobile VALUES(20,'RENAULT','CLIO','2019',11000,43000,'4',2,2,1500,2,2,20);
INSERT INTO automobile VALUES(21,'RENAULT','MEGANE','2019',30000,77000,'1',2,4,1800,2,1,21);
INSERT INTO automobile VALUES(22,'RENAULT','CLIO RS','2018',22000,81000,'1',2,4,1600,1,1,22);
INSERT INTO automobile VALUES(23,'FERRARI','F8','2022',342000,9000,'1',1,6,3900,3,2,23);
INSERT INTO automobile VALUES(24,'FERRARI','488','2016',220000,30000,'1',1,7,3900,3,2,24);
INSERT INTO automobile VALUES(25,'FERRARI','CALIFORNIA','2016',149000,82000,'1',1,5,3900,3,2,25);
INSERT INTO automobile VALUES(26,'FORD','FOCUS','2019',20000,53000,'1',2,3,1000,1,1,26);
INSERT INTO automobile VALUES(27,'FORD','FIESTA','2019',16400,29800,'1',2,2,1100,2,1,27);
INSERT INTO automobile VALUES(28,'FORD','EDGE','2019',29500,150000,'4',2,2,2000,1,1,28);
INSERT INTO automobile VALUES(29,'LANCIA','YPSILON','2021',14900,44000,'6',2,3,1000,2,1,29);
INSERT INTO automobile VALUES(30,'LANCIA','DELTA','1992',108900,119000,'1',2,6,2000,2,1,30);
INSERT INTO automobile VALUES(31,'LANCIA','THEMA','2012',11000,250000,'4',2,9,3000,1,1,31);
INSERT INTO automobile VALUES(32,'PEUGEOT','2008','2019',19000,37000,'1',2,2,1200,2,1,32);
INSERT INTO automobile VALUES(33,'PEUGEOT','3008','2021',28000,57000,'1',2,2,1200,2,2,33);
INSERT INTO automobile VALUES(34,'PEUGEOT','508','2021',28900,35000,'4',2,3,1500,2,2,34);
INSERT INTO automobile VALUES(35,'OPEL','CORSA','2017',10500,64000,'1',2,4,1200,2,2,35);
INSERT INTO automobile VALUES(36,'OPEL','ANTARA','2016',15500,64000,'4',2,5,2000,1,2,36);
INSERT INTO automobile VALUES(37,'OPEL','CROSSLAND X','2022',26900,0,'4',2,2,1500,1,2,37);
INSERT INTO automobile VALUES(38,'FIAT','500','1966',39000,100,'1',2,4,500,2,1,38);
INSERT INTO automobile VALUES(39,'FIAT','124 SPIDER','2017',80000,45000,'1',1,6,1300,1,1,39);
INSERT INTO automobile VALUES(40,'FIAT','500 ABARTH','2019',24000,32000,'1',1,2,1400,2,1,40);
INSERT INTO automobile VALUES(41,'PORSCHE','911','2018',435000,712,'1',1,6,3800,3,2,41);
INSERT INTO automobile VALUES(42,'PORSCHE','CAYENNE','2022',230000,20000,'1',1,2,4000,3,2,42);
INSERT INTO automobile VALUES(43,'PORSCHE','MACAN','2022',110000,19000,'1',1,5,2900,3,2,43);
INSERT INTO automobile VALUES(44,'LAMBORGHINI','HURACAN','2020',330000,17000,'1',1,1,5200,3,2,44);
INSERT INTO automobile VALUES(45,'LAMBORGHINI','AVENTADOR','2021',920000,4000,'1',1,7,6500,3,2,45);
INSERT INTO automobile VALUES(46,'LAMBORGHINI','URUS','2022',590000,15000,'1',2,5,4000,3,2,46);
INSERT INTO automobile VALUES(47,'VOLKSWAGEN','GOLF','2021',54900,23400,'1',2,5,2000,1,2,47);
INSERT INTO automobile VALUES(48,'VOLKSWAGEN','GOLF','2020',31200,10500,'1',2,3,2000,1,2,48);
INSERT INTO automobile VALUES(49,'VOLKSWAGEN','TIGUAN','2021',54000,39000,'1',2,2,2000,1,2,49); 
INSERT INTO automobile VALUES(50,'TOYOTA','RAV4','2021',49000,14000,'6',2,2,2500,1,2,50); 
INSERT INTO automobile VALUES(51,'TOYOTA','SUPRA','2022',57000,0,'1',1,6,2000,1,2,51); 
INSERT INTO automobile VALUES(52,'TOYOTA','YARIS','2022',70000,1000,'1',2,5,1600,2,1,52); 


INSERT INTO annuncio VALUES(1,'4X4 1100 METANO','2023-1-15','BARI','BA','70125',1,1);
INSERT INTO annuncio VALUES(2,'1.2 BENZINA DUEALOGIC ','2023-1-10','RIVOLI','TO','10098',2,2);
INSERT INTO annuncio VALUES(3,'1.3 mjt 16v Young 75cv ','2022-6-12','ROMA','RM','00198',3,3);
INSERT INTO annuncio VALUES(4,'1.2 Easy Lounge ','2023-1-15','TORINO','TO','10098',4,4);
INSERT INTO annuncio VALUES(5,'Sportback 1.6 tdi Business s-tronic','2023-1-1','MILANO','MI','20026',5,5);
INSERT INTO annuncio VALUES(6,'Sportback 2.0 tdi quattro 150cv','2022-5-1','SAVONA','SV','20024',6,6);
INSERT INTO annuncio VALUES(7,'SPORTBACK 2.5 400CV QUATTRO S-TRONIC','2023-1-16','NAPOLI','NA','80016',7,7);
INSERT INTO annuncio VALUES(8,'2.2 Turbodiesel 210 CV AT8 Q4','2023-1-3','BARI','BA','70123',8,8);
INSERT INTO annuncio VALUES(9,' 2.9 t V6 Quadrifoglio 510cv','2021-5-3','MILANO','MI','20024',9,9);
INSERT INTO annuncio VALUES(10,'2.9 V6 510cv Quadrifoglio Q4','2022-11-7','VERONA','VR','10023',10,10);
INSERT INTO annuncio VALUES(11,'cat Eletta','2022-7-2','BERGAMO','BG','10345',11,11);
INSERT INTO annuncio VALUES(12,'Touring Msport CL19 ACC','2023-1-2','FOGGIA','FG','71121',12,12);
INSERT INTO annuncio VALUES(13,'AKRAPOVIC/PACK PERFORMANCE','2022-5-2','ROMA','RM','00119',13,13);
INSERT INTO annuncio VALUES(14,'Sport MY16 FULL LED','2021-3-5','FIRENZE','FI','10019',14,14);
INSERT INTO annuncio VALUES(15,'S Edition','2022-9-6','NAPOLI','NA','80011',15,15);
INSERT INTO annuncio VALUES(16,'Classe Coupé','2023-1-16','MILANO','MI','20011',16,16);
INSERT INTO annuncio VALUES(17,'4.7 Sport cambiocorsa','2021-2-10','TORINO','TO','10098',17,17);
INSERT INTO annuncio VALUES(18,'GT Hybrid 330 CV MY22','2022-6-12','LUCERA','FG','71011',18,18);
INSERT INTO annuncio VALUES(19,'4.7 MC','2022-10-1','ROMA','RM','00111',19,19);
INSERT INTO annuncio VALUES(20,'1.5 Life 75cv','2022-4-15','MILANO','MI','20013',20,20);
INSERT INTO annuncio VALUES(21,'1.8 tce RS 280cv','2022-11-19','BARI','BA','70013',21,21);
INSERT INTO annuncio VALUES(22,'1.6 tce energy RS Trophy 220cv','2022-12-5','NAPOLI','NA','80013',22,22);
INSERT INTO annuncio VALUES(23,'Tributo Coupe 3.9 ','2023-1-18','MILANO','MI','20017',23,23);
INSERT INTO annuncio VALUES(24,'GTB','2022-3-7','ROMA','RM','00198',24,24);
INSERT INTO annuncio VALUES(25,'3.9 Handling Speciale','2022-5-26','BARI','BA','70123',25,25);
INSERT INTO annuncio VALUES(26,'Ford Focus Station Wagon 1.0 EcoBoost ST-Line','2023-1-10','MILANO','MI','20024',26,26);
INSERT INTO annuncio VALUES(27,'Ford Fiesta 7ª serie 1.1 85 CV 5 porte ST-Line','2023-1-4','NAPOLI','NA','80131',27,27);
INSERT INTO annuncio VALUES(28,'Ford Edge 2.0 ecoblue ST-Line s','2022-5-12','ROMA','RM','00118',28,28);
INSERT INTO annuncio VALUES(29,'Lancia Ypsilon 1.0 FireFly S&S Hybrid Gold','2022-10-17','FOGGIA','FG','71121',29,29);
INSERT INTO annuncio VALUES(30,'Lancia Delta Integrale HF Evo 1 Sacca Intercooler','2023-1-7','BARI','BA','70121',30,30);
INSERT INTO annuncio VALUES(31,'Lancia Thema 3.0 V6 mjt II Platinum 190cv ','2022-11-23','FIRENZE','FI','10019',31,31);
INSERT INTO annuncio VALUES(32,'PEUGEOT 2008 turbo 130cv puretech allure','2022-12-21','MILANO','MI','20024',32,32);
INSERT INTO annuncio VALUES(33,'PEUGEOT 3008 turbo 130cv puretech allure','2023-1-24','ROMA','RM','00118',33,33);
INSERT INTO annuncio VALUES(34,'PEUGEOT 508 BlueHDi 130 Stop&Start EAT8 Allure','2023-1-7','BOLOGNA','BO','40131',34,34);
INSERT INTO annuncio VALUES(35,'Opel Corsa 1.2 b-Color','2022-5-21','BARI','BA','70121',35,35);
INSERT INTO annuncio VALUES(36,'Opel Antara 2.0 CDTI 170CV 4X2 aut.','2023-1-7','MILANO','MI','20131',36,36);
INSERT INTO annuncio VALUES(37,'Opel Crossland X 1.5 ecotec GS Line 120cv at6','2023-1-24','FOGGIA','FG','71121',37,37);
INSERT INTO annuncio VALUES(38,'Fiat 500','2021-8-6','NAPOLI','NA','80131',38,38);
INSERT INTO annuncio VALUES(39,'Fiat 124 Spider 1.4 m-air','2022-8-2','LECCE','LE','73100',39,39);
INSERT INTO annuncio VALUES(40,'Fiat 500 Abarth 595 COMPETIZIONE 180HP','2022-4-30','FIRENZE','FI','50100',40,40);
INSERT INTO annuncio VALUES(41,'Porsche 991 3.8 Speedster','2023-1-12','ROMA','RM','00118',41,41);
INSERT INTO annuncio VALUES(42,'Porsche Cayenne Coupe 4.0 Turbo GT tiptronic','2023-1-25','BOLOGNA','BO','40131',42,42);
INSERT INTO annuncio VALUES(43,'Porsche Macan GTS 2.9 440CV PDK','2023-1-21','MILANO','MI','20131',43,43);
INSERT INTO annuncio VALUES(44,'Lamborghini Huracan Spyder 5.2 Evo 640 awd','2022-5-2','BARI','BA','70121',44,44);
INSERT INTO annuncio VALUES(45,'Lamborghini Aventador Roadster 6.5 V12 SVJ','2022-9-13','LECCE','LE','73100',45,45);
INSERT INTO annuncio VALUES(46,'Lamborghini Urus MANSORY 4.0 V8 ','2023-1-12','FIRENZE','FI','50100',46,46);
INSERT INTO annuncio VALUES(47,'Volkswagen Golf R 2.0 320cv','2022-9-3','ROMA','RM','00118',47,47);
INSERT INTO annuncio VALUES(48,'Volkswagen Golf GTI 2.0 tsi 231cv DSG GTI','2022-4-7','MILANO','MI','20131',48,48);
INSERT INTO annuncio VALUES(49,'Volkswagen Tiguan 2.0 tsi R 4motion 320cv dsg','2022-6-11','TORINO','TO','10121',49,49);
INSERT INTO annuncio VALUES(50,'Toyota RAV 4 2.5 vvt-ie phev Dynamic','2023-1-27','FOGGIA','FG','71121',50,50);
INSERT INTO annuncio VALUES(51,'Toyota Supra GR SUPRA 20 ','2023-1-8','BERGAMO','BG','24121',51,51);
INSERT INTO annuncio VALUES(52,'Toyota Yaris GR 1.6 Circuit','2023-1-10','NAPOLI','NA','80131',52,52);



INSERT INTO utente VALUES(1,'MICHELE','GIAMPIETRO','michelegiamp@google.com','FoggiaAle','FOGGIA');
INSERT INTO utente VALUES(2,'EUGENIO','DE PALO','eugeniodep99@google.com','myra bistrot','BARI');
INSERT INTO utente VALUES(3,'DAVIDE','TAFURI','davidetaf98@google.com','forzajuve','NAPOLI');
INSERT INTO utente VALUES(4,'PIO','PISCITELLI','pionapoli@google.com','forzanapoli','NAPOLI');
INSERT INTO utente VALUES(5,'ELENA','NYEGREA','blondelena@google.com','elenaid','CAGLIARI');
INSERT INTO utente VALUES(6,'TIZIANO','SERRITELLA','tizianoser@google.com','sertiziano','SALERNO');
INSERT INTO utente VALUES(7,'ROBERTO','SERRITELLA','robertoser@google.com','serrirobertoo','SALERNO');
INSERT INTO utente VALUES(8,'VINCENZO','TEOFILO','enzoteofilo@google.com','enzoteofilo5','BARI');
INSERT INTO utente VALUES(9,'NICOLA','ALBANO','nicolaalbano@google.com','nicolalba','MILANO');
INSERT INTO utente VALUES(10,'MARIO','ROSSI','mariorossi@google.com','mariored','VERONA');
INSERT INTO utente VALUES(11,'ANDREA','VERDE','andreaverde@google.com','andreaverde','BERGAMO');
INSERT INTO utente VALUES(12,'GUIDO','BIANCHI','guidobianchi@google.com','guidobianchi','FOGGIA');
INSERT INTO utente VALUES(13,'DANIELE','MANCINI','danimancini@google.com','danimancini','ROMA');
INSERT INTO utente VALUES(14,'LUCA','ROMANO','lucaromano@google.com','lucaromano','FIRENZE');
INSERT INTO utente VALUES(15,'FILIPPO','ROSSI','filipporossi@google.com','filirossi','NAPOLI');
INSERT INTO utente VALUES(16,'GIUSEPPE','RUSSO','giusepperusso@google.com','giusepperusso','MILANO');
INSERT INTO utente VALUES(17,'CIRO','ESPOSITO','espositociro@google.com','ciroesp','TORINO');
INSERT INTO utente VALUES(18,'SAMUELE','PINTO','samupinto@google.com','samupinto','LUCERA');
INSERT INTO utente VALUES(19,'DANIELE','CORVINO','danielecorv@google.com','danielecorv','ROMA');
INSERT INTO utente VALUES(20,'ANGELO','DELUCA','delucaangelo@google.com','angelodeluca','MILANO');
INSERT INTO utente VALUES(21,'FRANCESCO','RENDINE','francescorendine@google.com','francescorendine','BARI');
INSERT INTO utente VALUES(22,'FABIO','RUSSO','fabiorusso@google.com','fabiorusso','NAPOLI');
INSERT INTO utente VALUES(23,'ANTONIO','BRUNO','brunoantonio@google.com','antoniobruno','MILANO');
INSERT INTO utente VALUES(24,'FRANCESCO','NERI','francesconeri@google.com','francesconeri','ROMA');
INSERT INTO utente VALUES(25,'FILIPPO','TUCCI','tuccifilippo@google.com','filippotucci','BARI');
INSERT INTO utente VALUES(26,'FRANCESCO','SARDI','francescosardi@google.com','francescosardi','MILANO');
INSERT INTO utente VALUES(27,'ALFONSO','DE ANGELIS','alfodeangelis@google.com','alfodeangelis','NAPOLI');
INSERT INTO utente VALUES(28,'PIO','DELLI SANTI','piodellisanti@google.com','piodellisanti','ROMA');
INSERT INTO utente VALUES(29,'DAVIDE','PIRACCI','davidepiracci@google.com','davidepiracci','FOGGIA');
INSERT INTO utente VALUES(30,'GIACOMO','CURATOLO','giacomocuratolo@google.com','giacomocuratolo','BARI');
INSERT INTO utente VALUES(31,'GIOVANNI','PADALINO','giovannipadalino@google.com','giovannipadalino','FIRENZE');
INSERT INTO utente VALUES(32,'CIRO','VENUTI','cirovenuti@google.com','cirovenuti','MILANO');
INSERT INTO utente VALUES(33,'ANTONIO','LOPS','antoniolops@google.com','antonolops','ROMA');
INSERT INTO utente VALUES(34,'ARMANDO','LIOCE','armandolioce@google.com','armandolioce','BOLOGNA');
INSERT INTO utente VALUES(35,'LUCA','GESUALDO','lucagesualdo@google.com','lucagesualdo','BARI');
INSERT INTO utente VALUES(36,'GIUSEPPE','VIGILANTE','giuseppevigilante@google.com','giuseppevigilante','MILANO');
INSERT INTO utente VALUES(37,'CRISTIAN','RUSSO','cristianrusso@google.com','cristianrusso','FOGGIA');
INSERT INTO utente VALUES(38,'ALESSIO','CITOLI','alessiocitoli@google.com','alessiocitoli','NAPOLI');
INSERT INTO utente VALUES(39,'NICOLA','FARCI','nicolafarci@google.com','nicolafarci','LECCE');
INSERT INTO utente VALUES(40,'LUIGI','BRATTI','luigibratti@google.com','luigibratti','FIRENZE');
INSERT INTO utente VALUES(41,'GABRIEL','MARIANI','gabrielmariani@google.com','gabrielmariani','ROMA');
INSERT INTO utente VALUES(42,'ANGELO','CAIONE','angelocaione@google.com','angelocaione','BOLOGNA');
INSERT INTO utente VALUES(43,'MARIO','ROSSI','mariorossi9@google.com','mariorossi','MILANO');
INSERT INTO utente VALUES(44,'SALVATORE','STRIDI','salvatorestridi@google.com','salvatorestridi','BARI');
INSERT INTO utente VALUES(45,'FRANCESCO','SCOPECE','francescoscopece@google.com','francescoscopece','LECCE');
INSERT INTO utente VALUES(46,'LUCA','MERCURIO','lucamercurio@google.com','lucamercurio','FIRENZE');
INSERT INTO utente VALUES(47,'GIOVANNI','LA ROCCA','giovannilaroc@google.com','giovannilarocca','ROMA');
INSERT INTO utente VALUES(48,'MATTEO','VENDITTI','matteovenditti@google.com','matteovenditti','MILANO');
INSERT INTO utente VALUES(49,'DAVIDE','VALORI','davidevalori@google.com','davidevalori','TORINO');
INSERT INTO utente VALUES(50,'ANDREA','VALENTE','andreavalente@google.com','andreavalente','FOGGIA');
INSERT INTO utente VALUES(51,'GUIDO','FIERRO','guidofierro@google.com','guidofierro','BERGAMO');
INSERT INTO utente VALUES(52,'ALESSIO','TORRACO','alessiotorraco@google.com','alessiotorraco','NAPOLI');


INSERT INTO foto VALUES(1,'https://tinyurl.com/8tv6wp67',1);
INSERT INTO foto VALUES(2,'https://tinyurl.com/5ekp27wv',1);
INSERT INTO foto VALUES(3,'https://tinyurl.com/yc6cm5ds',2);
INSERT INTO foto VALUES(4,'https://tinyurl.com/mpty3pp4',2);
INSERT INTO foto VALUES(5,'https://tinyurl.com/57xxwd23',2);
INSERT INTO foto VALUES(6,'https://tinyurl.com/mshmkh4r',3);
INSERT INTO foto VALUES(7,'https://tinyurl.com/98a7w8aj',3);
INSERT INTO foto VALUES(8,'https://tinyurl.com/yc7x2k39',3);
INSERT INTO foto VALUES(9,'https://tinyurl.com/yudmtd6f',4);
INSERT INTO foto VALUES(10,'https://tinyurl.com/57axwr8j',4);
INSERT INTO foto VALUES(11,'https://tinyurl.com/28fay3es',4);
INSERT INTO foto VALUES(12,'https://tinyurl.com/y8vuxnwk',5);
INSERT INTO foto VALUES(13,'https://tinyurl.com/32f2wsbj',5);
INSERT INTO foto VALUES(14,'https://tinyurl.com/28vm72tz',5);
INSERT INTO foto VALUES(15,'https://tinyurl.com/yck4xawm',5);
INSERT INTO foto VALUES(16,'https://tinyurl.com/4rf9tzed',6);
INSERT INTO foto VALUES(17,'https://tinyurl.com/bdd2yt3t',6);
INSERT INTO foto VALUES(18,'https://tinyurl.com/2zuxbx4m',6);
INSERT INTO foto VALUES(19,'https://tinyurl.com/2tu8wukt',7);
INSERT INTO foto VALUES(20,'https://tinyurl.com/4tvkmhhj',7);
INSERT INTO foto VALUES(21,'https://tinyurl.com/56a9ddpz',7);
INSERT INTO foto VALUES(22,'https://tinyurl.com/2rw5sx62',8);
INSERT INTO foto VALUES(23,'https://tinyurl.com/2tahkf2k',8);
INSERT INTO foto VALUES(24,'https://tinyurl.com/553kbdfn',8);
INSERT INTO foto VALUES(25,'https://tinyurl.com/bdh6as76',9);
INSERT INTO foto VALUES(26,'https://tinyurl.com/bddnufc9',9);
INSERT INTO foto VALUES(27,'https://tinyurl.com/ms9yras6',9);
INSERT INTO foto VALUES(28,'https://tinyurl.com/2785hvu5',10);
INSERT INTO foto VALUES(29,'https://tinyurl.com/b56erypx',10);
INSERT INTO foto VALUES(30,'https://tinyurl.com/2bz3w2fu',10);
INSERT INTO foto VALUES(31,'https://tinyurl.com/2s3h436w',11);
INSERT INTO foto VALUES(32,'https://tinyurl.com/2bhbamcw',11);
INSERT INTO foto VALUES(33,'https://tinyurl.com/3nsdheyu',11);
INSERT INTO foto VALUES(34,'https://tinyurl.com/3sbusvjc',12);
INSERT INTO foto VALUES(35,'https://tinyurl.com/ydpfppuw',12);
INSERT INTO foto VALUES(36,'https://tinyurl.com/md6neafz',12);
INSERT INTO foto VALUES(37,'https://tinyurl.com/yc4u5rby',13);
INSERT INTO foto VALUES(38,'https://tinyurl.com/ydun9ha3',13);
INSERT INTO foto VALUES(39,'https://tinyurl.com/bdctz4vv',13);
INSERT INTO foto VALUES(40,'https://tinyurl.com/yyhbk7kx',14);
INSERT INTO foto VALUES(41,'https://tinyurl.com/m353kw53',14);
INSERT INTO foto VALUES(42,'https://tinyurl.com/3bfrxkhe',14);
INSERT INTO foto VALUES(43,'https://tinyurl.com/2p8wmyen',15);
INSERT INTO foto VALUES(44,'https://tinyurl.com/5t2v4b4n',15);
INSERT INTO foto VALUES(45,'https://tinyurl.com/3tkpb6x7',15);
INSERT INTO foto VALUES(46,'https://tinyurl.com/mr3atzab',16);
INSERT INTO foto VALUES(47,'https://tinyurl.com/bdd2kejy',16);
INSERT INTO foto VALUES(48,'https://tinyurl.com/yy3e2636',16);
INSERT INTO foto VALUES(49,'https://tinyurl.com/5hdjur93',17);
INSERT INTO foto VALUES(50,'https://tinyurl.com/486cb3jc',17);
INSERT INTO foto VALUES(51,'https://tinyurl.com/t4h3ypkj',17);
INSERT INTO foto VALUES(52,'https://tinyurl.com/59phd79u',18);
INSERT INTO foto VALUES(53,'https://tinyurl.com/52pddrx4',18);
INSERT INTO foto VALUES(54,'https://tinyurl.com/fhc8ck49',18);
INSERT INTO foto VALUES(55,'https://tinyurl.com/38a9pskj',19);
INSERT INTO foto VALUES(56,'https://tinyurl.com/2d6zkp47',19);
INSERT INTO foto VALUES(57,'https://tinyurl.com/6x4xmjk7',19);
INSERT INTO foto VALUES(58,'https://tinyurl.com/9a6f7eue',20);
INSERT INTO foto VALUES(59,'https://tinyurl.com/mv6ck7fh',20);
INSERT INTO foto VALUES(60,'https://tinyurl.com/3pefbwk5',20);
INSERT INTO foto VALUES(61,'https://tinyurl.com/2epp8z5u',21);
INSERT INTO foto VALUES(62,'https://tinyurl.com/25asm9d3',21);
INSERT INTO foto VALUES(63,'https://tinyurl.com/43hxntm2',21);
INSERT INTO foto VALUES(64,'https://tinyurl.com/2s4ehe3d',22);
INSERT INTO foto VALUES(65,'https://tinyurl.com/bddm3z6h',22);
INSERT INTO foto VALUES(66,'https://tinyurl.com/53tsyn7d',22);
INSERT INTO foto VALUES(67,'https://tinyurl.com/24hsc2cy',23);
INSERT INTO foto VALUES(68,'https://tinyurl.com/8dtfw8r8',23);
INSERT INTO foto VALUES(69,'https://tinyurl.com/mr2m9yvf',23);
INSERT INTO foto VALUES(70,'https://tinyurl.com/5n965efz',24);
INSERT INTO foto VALUES(71,'https://tinyurl.com/2shz7tnw',24);
INSERT INTO foto VALUES(72,'https://tinyurl.com/y5ec2wz2',24);
INSERT INTO foto VALUES(73,'https://tinyurl.com/vv43t483',25);
INSERT INTO foto VALUES(74,'https://tinyurl.com/yc5vjspc',25);
INSERT INTO foto VALUES(75,'https://tinyurl.com/5n7ymc76',25);
INSERT INTO foto VALUES(76,'https://tinyurl.com/3zwvtkbh',26);
INSERT INTO foto VALUES(77,'https://tinyurl.com/3az5fmjx',26);
INSERT INTO foto VALUES(78,'https://tinyurl.com/mw5h3nvf',26);
INSERT INTO foto VALUES(79,'https://tinyurl.com/426vt5w3',27);
INSERT INTO foto VALUES(80,'https://tinyurl.com/mpepd7cm',27);
INSERT INTO foto VALUES(81,'https://tinyurl.com/y8n2f7cv',27);
INSERT INTO foto VALUES(82,'https://tinyurl.com/3558ptwu',28);
INSERT INTO foto VALUES(83,'https://tinyurl.com/2zdfhuyv',28);
INSERT INTO foto VALUES(84,'https://tinyurl.com/2x29eksu',28);
INSERT INTO foto VALUES(85,'https://tinyurl.com/yk56nv6k',29);
INSERT INTO foto VALUES(86,'https://tinyurl.com/2s4mxpwa',29);
INSERT INTO foto VALUES(87,'https://tinyurl.com/23fexpf4',29);
INSERT INTO foto VALUES(88,'https://tinyurl.com/5y5nzr56',30);
INSERT INTO foto VALUES(89,'https://tinyurl.com/yc2u9hx7',30);
INSERT INTO foto VALUES(90,'https://tinyurl.com/mr2we7j9',30);
INSERT INTO foto VALUES(91,'https://tinyurl.com/yd8t3kuj',31);
INSERT INTO foto VALUES(92,'https://tinyurl.com/58x6rerj',31);
INSERT INTO foto VALUES(93,'https://tinyurl.com/3vth6wjh',31);
INSERT INTO foto VALUES(94,'https://tinyurl.com/yckf5ddu',32);
INSERT INTO foto VALUES(95,'https://tinyurl.com/4z3dkrp3',32);
INSERT INTO foto VALUES(96,'https://tinyurl.com/2avnsz5y',32);
INSERT INTO foto VALUES(97,'https://tinyurl.com/yc654um3',33);
INSERT INTO foto VALUES(98,'https://tinyurl.com/mrxcvu2b',33);
INSERT INTO foto VALUES(99,'https://tinyurl.com/2zs2xyvm',33);
INSERT INTO foto VALUES(100,'https://tinyurl.com/2p8wwm28',34);
INSERT INTO foto VALUES(101,'https://tinyurl.com/mv494afx',34);
INSERT INTO foto VALUES(102,'https://tinyurl.com/s2vhberd',34);
INSERT INTO foto VALUES(103,'https://tinyurl.com/2p8jwhkc',35);
INSERT INTO foto VALUES(104,'https://tinyurl.com/4m249f37',35);
INSERT INTO foto VALUES(105,'https://tinyurl.com/2vzm22rm',35);
INSERT INTO foto VALUES(106,'https://tinyurl.com/4kj556xb',36);
INSERT INTO foto VALUES(107,'https://tinyurl.com/e6puyesv',36);
INSERT INTO foto VALUES(108,'https://tinyurl.com/24ev47sf',36);
INSERT INTO foto VALUES(109,'https://tinyurl.com/y6fu5tjf',37);
INSERT INTO foto VALUES(110,'https://tinyurl.com/2s4hhrwz',37);
INSERT INTO foto VALUES(111,'https://tinyurl.com/3hu29xxw',37);
INSERT INTO foto VALUES(112,'https://tinyurl.com/4j2hbymj',38);
INSERT INTO foto VALUES(113,'https://tinyurl.com/3f7myyhf',38);
INSERT INTO foto VALUES(114,'https://tinyurl.com/mv5dedt2',38);
INSERT INTO foto VALUES(115,'https://tinyurl.com/4tfkzux4',39);
INSERT INTO foto VALUES(116,'https://tinyurl.com/yshhhumh',39);
INSERT INTO foto VALUES(117,'https://tinyurl.com/2p8z3nus',39);
INSERT INTO foto VALUES(118,'https://tinyurl.com/4dbcznv7',40);
INSERT INTO foto VALUES(119,'https://tinyurl.com/4z9ubpjr',40);
INSERT INTO foto VALUES(120,'https://tinyurl.com/4fn99xxu',40);
INSERT INTO foto VALUES(121,'https://tinyurl.com/2bc9ppfx',41);
INSERT INTO foto VALUES(122,'https://tinyurl.com/62ytpsmj',41);
INSERT INTO foto VALUES(123,'https://tinyurl.com/2s67vts3',41);
INSERT INTO foto VALUES(124,'https://tinyurl.com/43u3ye4d',42);
INSERT INTO foto VALUES(125,'https://tinyurl.com/yc4yedca',42);
INSERT INTO foto VALUES(126,'https://tinyurl.com/wxau8tj9',42);
INSERT INTO foto VALUES(127,'https://tinyurl.com/4h3tf7sw',43);
INSERT INTO foto VALUES(128,'https://tinyurl.com/2npx2kfd',43);
INSERT INTO foto VALUES(129,'https://tinyurl.com/y2bp3sj3',43);
INSERT INTO foto VALUES(130,'https://tinyurl.com/29x7r467',44);
INSERT INTO foto VALUES(131,'https://tinyurl.com/3yhvc4ra',44);
INSERT INTO foto VALUES(132,'https://tinyurl.com/3jbca244',44);
INSERT INTO foto VALUES(133,'https://tinyurl.com/2p8b8j93',45);
INSERT INTO foto VALUES(134,'https://tinyurl.com/3mkre925',45);
INSERT INTO foto VALUES(135,'https://tinyurl.com/2ytumynz',45);
INSERT INTO foto VALUES(136,'https://tinyurl.com/ye27uszz',46);
INSERT INTO foto VALUES(137,'https://tinyurl.com/ypscp97r',46);
INSERT INTO foto VALUES(138,'https://tinyurl.com/2p8hdtbs',46);
INSERT INTO foto VALUES(139,'https://tinyurl.com/ym9pv7b9',47);
INSERT INTO foto VALUES(140,'https://tinyurl.com/2tarxxj3',47);
INSERT INTO foto VALUES(141,'https://tinyurl.com/3va4yv72',47);
INSERT INTO foto VALUES(142,'https://tinyurl.com/yc3w2dcb',48);
INSERT INTO foto VALUES(143,'https://tinyurl.com/5d4zc6c6',48);
INSERT INTO foto VALUES(144,'https://tinyurl.com/5pmbsdue',48);
INSERT INTO foto VALUES(145,'https://tinyurl.com/mryd6kz6',49);
INSERT INTO foto VALUES(146,'https://tinyurl.com/5n7t7p4u',49);
INSERT INTO foto VALUES(147,'https://tinyurl.com/mpb2hudv',49);
INSERT INTO foto VALUES(148,'https://tinyurl.com/bdhrw35v',50);
INSERT INTO foto VALUES(149,'https://tinyurl.com/4dvy3z24',50);
INSERT INTO foto VALUES(150,'https://tinyurl.com/yr4z8xzc',50);
INSERT INTO foto VALUES(151,'https://tinyurl.com/2p8bnkes',51);
INSERT INTO foto VALUES(152,'https://tinyurl.com/2s3745kv',51);
INSERT INTO foto VALUES(153,'https://tinyurl.com/4vfdtphv',51);
INSERT INTO foto VALUES(154,'https://tinyurl.com/mryckh5n',52);
INSERT INTO foto VALUES(155,'https://tinyurl.com/2p9ahxux',52);
INSERT INTO foto VALUES(156,'https://tinyurl.com/muxp49f5',52);