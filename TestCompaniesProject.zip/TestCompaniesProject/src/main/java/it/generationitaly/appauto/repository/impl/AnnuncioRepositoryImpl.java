package it.generationitaly.appauto.repository.impl;

import java.sql.Date;
import java.util.List;
import java.util.StringJoiner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import it.generationitaly.appauto.entity.Annuncio;
import it.generationitaly.appauto.entity.Colore;
import it.generationitaly.appauto.repository.AnnuncioRepository;

public class AnnuncioRepositoryImpl extends CrudRepositoryImpl<Annuncio, Integer> implements AnnuncioRepository {

	public AnnuncioRepositoryImpl() {
		super(Annuncio.class);

	}

	@Override
	public List<Annuncio> findByMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em
					.createQuery("select a from Annuncio a  join a.automobile au  where au.marca = :m", Annuncio.class)
					.setParameter("m", marca);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			System.out.println("mi blocco qui");
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;

	}

	@Override
	public List<Annuncio> findByModello(String modello) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em
					.createQuery("select a from Annuncio a  join a.automobile au  where au.modello = :modello",
							Annuncio.class)
					.setParameter("modello", modello);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;

	}

	@Override
	public List<Annuncio> betweenPrezzo(double min, double max) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select a from Annuncio a  join a.automobile au  where au.prezzo between :min and :max  ",
					Annuncio.class);
			q.setParameter("min", min);
			q.setParameter("max", max);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;

	}

	@Override
	public List<Annuncio> prezzoAsc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.prezzo asc  ", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;

	}

	@Override
	public List<Annuncio> prezzoDesc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.prezzo desc  ", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;

	}

	@Override
	public List<Annuncio> betweenKm(int min, int max) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select a from Annuncio a  join a.automobile au  where au.km between :min and :max  ",
					Annuncio.class);
			q.setParameter("min", min);
			q.setParameter("max", max);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> kmAsc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.km asc  ", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> kmDesc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.km desc  ", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> betweenAnno(Date min, Date max) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			TypedQuery<Annuncio> q = em.createQuery(
					"select a from Annuncio a  join a.automobile au  where au.data between :min	and :max ",
					Annuncio.class);
			q.setParameter("min", min);
			q.setParameter("max", max);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> annoAsc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.anno asc", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> annoDesc() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au order by au.anno desc  ", Annuncio.class);

			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> prezzoAscAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.prezzo asc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> prezzoDescAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.prezzo desc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> kmAscAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.km asc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> kmDescAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.km desc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> annoAscAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.anno asc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> annoDescAndMarca(String marca) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery(
					"select an from Annuncio an join an.automobile au where au.marca=:marca order by au.anno desc",
					Annuncio.class);
			q.setParameter("marca", marca);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> findAllLimit6() {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();

			TypedQuery<Annuncio> q = em.createQuery("select an from Annuncio an ", Annuncio.class);
			q.setMaxResults(6);
			ann = q.getResultList();
			tx.commit();
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
			}
		}
		return ann;
	}

	@Override
	public List<Annuncio> orderBy(String marca,Integer porta,String venditore,String cambio,String carburante, Integer prezzoDa, Integer prezzoA, Integer kmDa, Integer kmA,
			Integer annoDa, Integer annoA,String[] colori, String orderBy, String ordine) {
		List<Annuncio> ann = null;
		EntityManager em = null;
		EntityTransaction tx = null;
		TypedQuery<Annuncio> q = null;

		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			String sqlOrderBy = "order by au." + orderBy + " " + ordine;
			String sqlWhere = "";
			StringJoiner joiner = new StringJoiner(" and ");

			if (marca != null && !marca.isEmpty()&& !marca.equals("null")) {
				joiner.add("au.marca=:marca");

			}
			if(venditore!=null && !venditore.isEmpty()) {
				joiner.add("au.venditore.nome=:venditore");
			}
			if(carburante!=null && !carburante.isEmpty()) {
				joiner.add("au.carburante.nome=:carburante");
			}
			if (prezzoDa != null) {
				joiner.add("au.prezzo>:prezzoDa");
			}
			if (prezzoA != null) {
				joiner.add("au.prezzo<=:prezzoA");
			}
			if (kmDa != null) {
				joiner.add("au.km>:kmDa");
			}
			if (kmA != null) {
				joiner.add("au.km<=:kmA");
			}
			if (annoDa != null) {
				joiner.add("au.anno>:annoDa");
			}
			if (annoA != null) {
				joiner.add("au.anno<=:annoA");
			}
			if(porta!=null) {
				joiner.add("au.porte.nome=:nome");
			}
			if(colori!=null && colori.length!=0) {
				StringJoiner colors=new StringJoiner(" or ");
				for(int i=0;i<colori.length;i++) {
					colors.add("au.colore.nome=:colore"+i);
				}
				joiner.add(colors.toString());
			}
			if(cambio!=null && !cambio.isEmpty()&& !cambio.equals("null")) {
				joiner.add("au.cambio.nome=:cambio");
			}
			

			sqlWhere = joiner.length() != 0 ? " where " + joiner.toString() : "";
			String jpql="select an from Annuncio an join an.automobile au" + sqlWhere + " " + sqlOrderBy;
			
			q = em.createQuery(jpql,Annuncio.class);
			System.out.println(jpql);
			if (marca != null) {
				q.setParameter("marca", marca);
			}
			if(venditore!=null ) {
				q.setParameter("venditore", venditore);
			}
			if(carburante!=null) {
				q.setParameter("carburante", carburante);
			}
			if (prezzoDa != null) {
				q.setParameter("prezzoDa", prezzoDa);
			}
			if (prezzoA != null) {
				q.setParameter("prezzoA", prezzoA);
			}
			if (kmDa != null) {
				q.setParameter("kmDa", kmDa);
			}
			if (kmA != null) {
				q.setParameter("kmA", kmA);
			}
			if (annoDa != null) {
				q.setParameter("annoDa", annoDa);
			}
			if (annoA != null) {
				q.setParameter("annoA", annoA);
			}
			if(porta!=null) {
				q.setParameter("porta", porta);
			}
			if(colori!=null && colori.length!=0) {
				for(int i=0;i<colori.length;i++) {
					q.setParameter("colore"+i, colori[i]);
				}
				
			}
			if(cambio!=null) {
				q.setParameter("cambio", cambio);
			}

			ann = q.getResultList();
			
			tx.commit();
			
		} catch (Exception e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
		} finally {
			if (em != null) {
				em.close();
				
			}
		}
		return ann;
	}

	@Override
	public int saveReturnId(Annuncio annuncio) {
		Integer id =null;
		EntityManager em = null;
		EntityTransaction tx = null;
		try {
			em = emf.createEntityManager();
			tx = em.getTransaction();
			tx.begin();
			em.persist(annuncio);
			tx.commit();
			id=annuncio.getId();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			if (tx != null && tx.isActive())
				tx.rollback();
		} finally {
			if (em != null)
				em.close();
		}
	return id;
	}
}
