package it.generationitaly.appauto.repository.impl;

import it.generationitaly.appauto.entity.Colore;
import it.generationitaly.appauto.repository.ColoreRepository;

public class ColoreRepositoryImpl extends CrudRepositoryImpl<Colore, Integer> implements ColoreRepository {

	public ColoreRepositoryImpl() {
		super(Colore.class);

	}

}